"""
Model Evaluation and Diagnostic Module for Movie Rating Prediction.
Generates evaluation charts:
- Actual vs Predicted ratings
- Residual plot
- Residual distribution
- Error by rating range
- Feature importance (model-based and permutation importance)
"""

import logging
from pathlib import Path
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

from src.config import (
    BEST_MODEL_PATH,
    CLEANED_DATA_PATH,
    TARGET_COL,
    TEST_SIZE,
    RANDOM_STATE,
    FIGURES_DIR,
    OUTPUTS_DIR,
    LOG_FILE_PATH,
    LOGS_DIR
)
from src.features import MovieFeatureEngineer

FIGURES_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, mode="a", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Evaluate")

plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
plt.rcParams["font.sans-serif"] = "DejaVu Sans"


def evaluate_best_model():
    """Run full evaluation suite on the held-out test set."""
    logger.info("Loading best model and cleaned data...")
    pipeline = joblib.load(BEST_MODEL_PATH)
    df = pd.read_csv(CLEANED_DATA_PATH)

    # Train / Test split (same random state 42)
    from sklearn.model_selection import train_test_split
    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
    )

    y_test_pred = pipeline.predict(X_test)
    y_test_arr = y_test.to_numpy()
    residuals = y_test_arr - y_test_pred

    mae = mean_absolute_error(y_test_arr, y_test_pred)
    rmse = root_mean_squared_error(y_test_arr, y_test_pred)
    r2 = r2_score(y_test_arr, y_test_pred)

    logger.info(f"Test Evaluation Metrics: MAE={mae:.4f}, RMSE={rmse:.4f}, R2={r2:.4f}")

    # 1. Actual vs Predicted Plot
    logger.info("Plotting: 09_actual_vs_predicted.png")
    fig, ax = plt.subplots(figsize=(7, 7))
    sns.regplot(
        x=y_test_arr,
        y=y_test_pred,
        scatter_kws={"alpha": 0.35, "color": "#1f77b4", "s": 25},
        line_kws={"color": "#ff7f0e", "linewidth": 2, "label": "Best Fit Line"},
        ax=ax
    )
    ax.plot([1, 10], [1, 10], "r--", linewidth=2, label="Ideal (y = x)")
    ax.set_title(f"Actual vs. Predicted Ratings on Held-Out Test Set\n(R² = {r2:.3f}, MAE = {mae:.3f})", fontsize=13, fontweight="bold", pad=10)
    ax.set_xlabel("Actual IMDb Rating", fontsize=11)
    ax.set_ylabel("Predicted IMDb Rating", fontsize=11)
    ax.set_xlim(1.0, 10.0)
    ax.set_ylim(1.0, 10.0)
    ax.legend(loc="upper left")
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "09_actual_vs_predicted.png", dpi=300)
    plt.close(fig)

    # 2. Residual Plot
    logger.info("Plotting: 10_residuals_vs_predicted.png")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(y_test_pred, residuals, alpha=0.35, color="#2ca02c", s=25)
    ax.axhline(0, color="red", linestyle="--", linewidth=1.8)
    ax.axhline(np.std(residuals), color="gray", linestyle=":", label=f"+1 Std ({np.std(residuals):.2f})")
    ax.axhline(-np.std(residuals), color="gray", linestyle=":", label=f"-1 Std (-{np.std(residuals):.2f})")
    ax.set_title("Residual Plot (Errors vs. Predicted Ratings)", fontsize=13, fontweight="bold", pad=10)
    ax.set_xlabel("Predicted Rating", fontsize=11)
    ax.set_ylabel("Residual (Actual - Predicted)", fontsize=11)
    ax.legend(loc="upper right")
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "10_residuals_vs_predicted.png", dpi=300)
    plt.close(fig)

    # 3. Residual Distribution Plot
    logger.info("Plotting: 11_residual_distribution.png")
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.histplot(residuals, kde=True, color="#9467bd", bins=35, edgecolor="white", ax=ax)
    ax.axvline(0, color="red", linestyle="--", linewidth=2, label="Zero Error")
    ax.axvline(np.mean(residuals), color="blue", linestyle=":", linewidth=2, label=f"Mean Error: {np.mean(residuals):.3f}")
    ax.set_title("Distribution of Residuals (Prediction Errors)", fontsize=13, fontweight="bold", pad=10)
    ax.set_xlabel("Residual (Actual - Predicted)", fontsize=11)
    ax.set_ylabel("Frequency", fontsize=11)
    ax.legend(loc="upper left")
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "11_residual_distribution.png", dpi=300)
    plt.close(fig)

    # 4. Error by Rating Range (Binned MAE)
    logger.info("Plotting: 12_error_by_rating_range.png")
    eval_df = pd.DataFrame({"Actual": y_test_arr, "Predicted": y_test_pred, "Abs_Error": np.abs(residuals)})
    bins = [1.0, 4.0, 5.5, 7.0, 8.5, 10.0]
    labels = ["1.0 - 4.0 (Poor)", "4.0 - 5.5 (Below Avg)", "5.5 - 7.0 (Average)", "7.0 - 8.5 (Good)", "8.5 - 10.0 (Masterpiece)"]
    eval_df["Rating_Tier"] = pd.cut(eval_df["Actual"], bins=bins, labels=labels, include_lowest=True)
    tier_summary = eval_df.groupby("Rating_Tier", observed=False)["Abs_Error"].agg(["mean", "count"]).reset_index()

    fig, ax = plt.subplots(figsize=(9, 5))
    sns.barplot(data=tier_summary, x="Rating_Tier", y="mean", palette="Blues_d", ax=ax, hue="Rating_Tier", legend=False)
    ax.axhline(mae, color="red", linestyle="--", linewidth=1.5, label=f"Overall MAE ({mae:.2f})")
    ax.set_title("Mean Absolute Error (MAE) Across Rating Tiers", fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Rating Tier", fontsize=11)
    ax.set_ylabel("Mean Absolute Error (MAE)", fontsize=11)
    for i, row in tier_summary.iterrows():
        ax.text(i, row["mean"] + 0.04, f"{row['mean']:.2f}\n(n={int(row['count'])})", ha="center", fontsize=9)
    ax.set_ylim(0, max(tier_summary["mean"]) + 0.3)
    ax.legend(loc="upper left")
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "12_error_by_rating_range.png", dpi=300)
    plt.close(fig)

    # 5. Feature Importance (Model-based & Permutation Importance)
    logger.info("Calculating feature importances...")
    fe = pipeline.named_steps["feature_engineer"]
    regressor = pipeline.named_steps["regressor"]
    X_test_transformed = fe.transform(X_test)
    feature_names = fe.feature_names_

    # XGBoost Gini / Gain feature importance
    raw_importances = regressor.feature_importances_
    feat_imp_df = pd.DataFrame({
        "Feature": feature_names,
        "Importance": raw_importances
    }).sort_values("Importance", ascending=False).head(15)

    # Permutation Importance
    logger.info("Computing Permutation Importance on test set...")
    perm = permutation_importance(
        regressor, X_test_transformed, y_test_arr, n_repeats=10, random_state=RANDOM_STATE, scoring="neg_mean_absolute_error"
    )
    perm_df = pd.DataFrame({
        "Feature": feature_names,
        "Mean_Importance": perm.importances_mean
    }).sort_values("Mean_Importance", ascending=False).head(15)

    logger.info("Plotting: 13_feature_importance.png")
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    sns.barplot(data=feat_imp_df, x="Importance", y="Feature", palette="viridis", ax=ax1, hue="Feature", legend=False)
    ax1.set_title("Top 15 Features by XGBoost Split/Gain Importance", fontsize=12, fontweight="bold")
    ax1.set_xlabel("Relative Importance", fontsize=10)

    sns.barplot(data=perm_df, x="Mean_Importance", y="Feature", palette="magma", ax=ax2, hue="Feature", legend=False)
    ax2.set_title("Top 15 Features by Permutation Importance (MAE Increase)", fontsize=12, fontweight="bold")
    ax2.set_xlabel("Drop in MAE Score When Shuffled", fontsize=10)

    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "13_feature_importance.png", dpi=300)
    plt.close(fig)

    # Save feature importance table to outputs/feature_importance.csv
    feat_imp_all = pd.DataFrame({
        "Feature": feature_names,
        "Model_Gain_Importance": raw_importances,
        "Permutation_Importance_Mean": perm.importances_mean
    }).sort_values("Model_Gain_Importance", ascending=False)
    feat_imp_all.to_csv(OUTPUTS_DIR / "feature_importance.csv", index=False)

    logger.info("Evaluation charts and importance files saved successfully.")


if __name__ == "__main__":
    evaluate_best_model()
