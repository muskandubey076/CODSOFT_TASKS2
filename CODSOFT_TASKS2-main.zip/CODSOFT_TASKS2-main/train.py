"""
Model Training Module for Movie Rating Prediction.
Handles train/test splitting, baseline benchmarking, Ridge, Random Forest,
Gradient Boosting, and XGBoost training with 5-fold cross-validation and hyperparameter tuning.
Saves the best model and preprocessing pipeline with joblib to models/.
"""

import logging
import json
from pathlib import Path
from typing import Dict, Any, Tuple
import joblib
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, KFold, cross_val_score, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

from src.config import (
    CLEANED_DATA_PATH,
    TARGET_COL,
    TEST_SIZE,
    RANDOM_STATE,
    CV_FOLDS,
    BEST_MODEL_PATH,
    METRICS_CSV_PATH,
    METRICS_MD_PATH,
    LOG_FILE_PATH,
    LOGS_DIR,
    MODELS_DIR,
    OUTPUTS_DIR
)
from src.features import MovieFeatureEngineer

MODELS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, mode="a", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Train")


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Calculate MAE, RMSE, and R2 regression metrics."""
    return {
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(root_mean_squared_error(y_true, y_pred)),
        "R2": float(r2_score(y_true, y_pred))
    }


def train_models() -> Tuple[Any, pd.DataFrame]:
    """
    Train baseline and candidate regression models, evaluate with 5-fold CV,
    tune top performers, save best model to disk, and save comparison metrics table.
    """
    logger.info("Loading cleaned dataset...")
    df = pd.read_csv(CLEANED_DATA_PATH)
    logger.info(f"Loaded {len(df)} cleaned records.")

    # 1. Mandatory Data Leakage Rule: Split data FIRST (80% train, 20% test)
    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
    )
    logger.info(f"Train split: {len(X_train)} samples, Test split: {len(X_test)} samples.")

    # Feature engineer: fit on train, transform train (OOF) and test
    fe = MovieFeatureEngineer(cv_folds=CV_FOLDS)
    X_train_fe = fe.fit_transform(X_train, y_train)
    X_test_fe = fe.transform(X_test)

    feature_cols = list(X_train_fe.columns)
    logger.info(f"Engineered {len(feature_cols)} features: {feature_cols}")

    # 2. Define Candidate Models
    models_dict = {
        "Baseline (Mean)": DummyRegressor(strategy="mean"),
        "Ridge Regression": Ridge(alpha=10.0, random_state=RANDOM_STATE),
        "Random Forest": RandomForestRegressor(
            n_estimators=150, max_depth=12, min_samples_split=6, random_state=RANDOM_STATE, n_jobs=-1
        ),
        "Gradient Boosting": GradientBoostingRegressor(
            n_estimators=150, learning_rate=0.08, max_depth=5, min_samples_split=6, random_state=RANDOM_STATE
        ),
        "XGBoost Regressor": XGBRegressor(
            n_estimators=150, learning_rate=0.08, max_depth=5, subsample=0.8, colsample_bytree=0.8,
            random_state=RANDOM_STATE, n_jobs=-1
        )
    }

    # 5-fold Cross-Validation setup on training set
    kf = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    metrics_records = []

    logger.info("Beginning model evaluations across 5-fold CV and Test set...")

    for name, model in models_dict.items():
        logger.info(f"Evaluating {name}...")

        # 5-fold CV for R2 and RMSE
        cv_r2 = cross_val_score(model, X_train_fe, y_train, cv=kf, scoring="r2", n_jobs=-1)
        cv_rmse = -cross_val_score(
            model, X_train_fe, y_train, cv=kf, scoring="neg_root_mean_squared_error", n_jobs=-1
        )
        cv_mae = -cross_val_score(
            model, X_train_fe, y_train, cv=kf, scoring="neg_mean_absolute_error", n_jobs=-1
        )

        # Fit model on entire training set
        model.fit(X_train_fe, y_train)

        # Train set evaluation (for overfitting check)
        y_train_pred = model.predict(X_train_fe)
        train_metrics = compute_metrics(y_train, y_train_pred)

        # Test set evaluation (held-out)
        y_test_pred = model.predict(X_test_fe)
        test_metrics = compute_metrics(y_test, y_test_pred)

        metrics_records.append({
            "Model": name,
            "CV_MAE_Mean": float(np.mean(cv_mae)),
            "CV_MAE_Std": float(np.std(cv_mae)),
            "CV_RMSE_Mean": float(np.mean(cv_rmse)),
            "CV_RMSE_Std": float(np.std(cv_rmse)),
            "CV_R2_Mean": float(np.mean(cv_r2)),
            "CV_R2_Std": float(np.std(cv_r2)),
            "Train_MAE": train_metrics["MAE"],
            "Train_RMSE": train_metrics["RMSE"],
            "Train_R2": train_metrics["R2"],
            "Test_MAE": test_metrics["MAE"],
            "Test_RMSE": test_metrics["RMSE"],
            "Test_R2": test_metrics["R2"]
        })

    # 3. Fine-tuning the best gradient boosted model (RandomForest & XGBoost)
    logger.info("Running Hyperparameter Optimization for XGBoost...")
    xgb_param_grid = {
        "n_estimators": [120, 180],
        "learning_rate": [0.05, 0.08],
        "max_depth": [4, 6],
        "subsample": [0.8, 1.0]
    }
    xgb_cv = GridSearchCV(
        XGBRegressor(random_state=RANDOM_STATE, n_jobs=-1),
        xgb_param_grid,
        cv=kf,
        scoring="neg_root_mean_squared_error",
        n_jobs=-1
    )
    xgb_cv.fit(X_train_fe, y_train)
    best_xgb_est = xgb_cv.best_estimator_
    logger.info(f"Best XGBoost Params: {xgb_cv.best_params_}")

    # Evaluate tuned XGBoost
    cv_r2_tuned = cross_val_score(best_xgb_est, X_train_fe, y_train, cv=kf, scoring="r2", n_jobs=-1)
    cv_rmse_tuned = -cross_val_score(best_xgb_est, X_train_fe, y_train, cv=kf, scoring="neg_root_mean_squared_error", n_jobs=-1)
    cv_mae_tuned = -cross_val_score(best_xgb_est, X_train_fe, y_train, cv=kf, scoring="neg_mean_absolute_error", n_jobs=-1)

    train_pred_tuned = best_xgb_est.predict(X_train_fe)
    test_pred_tuned = best_xgb_est.predict(X_test_fe)
    tuned_train_m = compute_metrics(y_train, train_pred_tuned)
    tuned_test_m = compute_metrics(y_test, test_pred_tuned)

    metrics_records.append({
        "Model": "XGBoost (Tuned - Best)",
        "CV_MAE_Mean": float(np.mean(cv_mae_tuned)),
        "CV_MAE_Std": float(np.std(cv_mae_tuned)),
        "CV_RMSE_Mean": float(np.mean(cv_rmse_tuned)),
        "CV_RMSE_Std": float(np.std(cv_rmse_tuned)),
        "CV_R2_Mean": float(np.mean(cv_r2_tuned)),
        "CV_R2_Std": float(np.std(cv_r2_tuned)),
        "Train_MAE": tuned_train_m["MAE"],
        "Train_RMSE": tuned_train_m["RMSE"],
        "Train_R2": tuned_train_m["R2"],
        "Test_MAE": tuned_test_m["MAE"],
        "Test_RMSE": tuned_test_m["RMSE"],
        "Test_R2": tuned_test_m["R2"]
    })

    metrics_df = pd.DataFrame(metrics_records)
    logger.info("\n=== Final Model Comparison Table ===\n" + metrics_df.to_string())

    # Save metrics table to outputs/metrics.csv and outputs/metrics.md
    metrics_df.to_csv(METRICS_CSV_PATH, index=False)
    metrics_df.to_markdown(METRICS_MD_PATH, index=False)
    logger.info(f"Metrics saved to {METRICS_CSV_PATH} and {METRICS_MD_PATH}")

    # Build end-to-end full inference pipeline with the best tuned model
    best_pipeline = Pipeline([
        ("feature_engineer", fe),
        ("regressor", best_xgb_est)
    ])

    # Re-fit the feature engineer on entire training set for deployment transform
    fe.fit(X_train, y_train)

    # Save artifacts bundle
    joblib.dump(best_pipeline, BEST_MODEL_PATH)
    logger.info(f"Best model pipeline saved to {BEST_MODEL_PATH}")

    # Save test set and predictions for evaluate.py
    test_export = X_test.copy()
    test_export["Rating"] = y_test
    test_export["Predicted_Rating"] = test_pred_tuned
    test_export.to_csv(OUTPUTS_DIR / "test_evaluation_results.csv", index=False)

    return best_pipeline, metrics_df


if __name__ == "__main__":
    train_models()
