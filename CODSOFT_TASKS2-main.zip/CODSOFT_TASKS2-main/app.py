"""
Streamlit Web Application for Movie Rating Prediction.
Features:
- Dataset Overview & Interactive Filters
- Dynamic Data Visualizations
- Model Performance & Comparative Benchmark Dashboard
- Interactive Single-Movie Rating Prediction Form
- Data, Metrics, and Predictions Export/Download capabilities
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import joblib
from pathlib import Path

from src.config import (
    CLEANED_DATA_PATH,
    METRICS_CSV_PATH,
    BEST_MODEL_PATH,
    OUTPUTS_DIR,
    ALL_GENRES
)
from src.predict import predict_rating

# Configure page settings
st.set_page_config(
    page_title="Movie Rating Prediction | CodSoft Data Science",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        color: #1E3A8A;
        font-weight: 700;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F3F4F6;
        border-radius: 8px;
        padding: 1rem;
        border-left: 4px solid #3B82F6;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_data
def load_data():
    df = pd.read_csv(CLEANED_DATA_PATH)
    return df


@st.cache_data
def load_metrics():
    if METRICS_CSV_PATH.exists():
        return pd.read_csv(METRICS_CSV_PATH)
    return pd.DataFrame()


df = load_data()
metrics_df = load_metrics()

# Sidebar Navigation
st.sidebar.image("https://img.icons8.com/color/96/000000/movie-projector.png", width=80)
st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Go to",
    ["🎬 Prediction Studio", "📊 Dataset Explorer", "📈 Model Benchmarks & Metrics", "💡 Insights & Findings"]
)

st.sidebar.markdown("---")
st.sidebar.info(
    "**CodSoft Data Science Internship**\n\n"
    "**Task 2**: Movie Rating Prediction\n\n"
    "**Model**: Tuned XGBoost Regressor\n\n"
    "**Test R²**: 0.44 | **Test MAE**: 0.76"
)

# -------------------------------------------------------------
# PAGE 1: PREDICTION STUDIO
# -------------------------------------------------------------
if page == "🎬 Prediction Studio":
    st.markdown('<p class="main-header">🎬 Movie Rating Prediction Studio</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Estimate IMDb ratings in real time using high-cardinality smoothed target encodings and gradient boosted trees.</p>', unsafe_allow_html=True)

    col1, col2 = st.columns([1, 1])

    with col1:
        st.subheader("Movie Characteristics")
        movie_title = st.text_input("Movie Title", value="Dangal")
        
        # Multiselect for genres
        selected_genres = st.multiselect(
            "Select Genre(s)",
            options=ALL_GENRES,
            default=["Biography", "Drama", "Sport"]
        )
        genre_str = ", ".join(selected_genres) if selected_genres else "Drama"

        year_val = st.slider("Release Year", min_value=1950, max_value=2026, value=2016)
        dur_val = st.slider("Runtime Duration (Minutes)", min_value=30, max_value=240, value=161)
        votes_val = st.number_input("Estimated User Votes count", min_value=10, max_value=1000000, value=180000, step=500)

    with col2:
        st.subheader("Cast & Crew")
        director_val = st.text_input("Director Name", value="Nitesh Tiwari")
        actor1_val = st.text_input("Lead Actor (Actor 1)", value="Aamir Khan")
        actor2_val = st.text_input("Supporting Actor 2", value="Fatima Sana Shaikh")
        actor3_val = st.text_input("Supporting Actor 3", value="Sanya Malhotra")

        st.write("")
        predict_btn = st.button("🚀 Predict Movie Rating", type="primary", use_container_width=True)

    if predict_btn:
        input_data = {
            "Name": movie_title,
            "Genre": genre_str,
            "Director": director_val,
            "Actor 1": actor1_val,
            "Actor 2": actor2_val,
            "Actor 3": actor3_val,
            "Year": year_val,
            "Duration": dur_val,
            "Votes": votes_val
        }

        try:
            res = predict_rating(input_data)
            pred_score = res["predicted_rating"]

            st.markdown("---")
            st.subheader("Prediction Result")
            res_c1, res_c2, res_c3 = st.columns([1, 1, 1])
            with res_c1:
                st.metric("Predicted IMDb Rating", f"{pred_score} / 10.0")
            with res_c2:
                tier = "Masterpiece" if pred_score >= 8.0 else ("Good" if pred_score >= 6.5 else ("Average" if pred_score >= 5.0 else "Poor"))
                st.metric("Expected Critical Tier", tier)
            with res_c3:
                st.metric("Confidence Benchmark", f"MAE ± {0.77:.2f} pts")

            if res["warnings"]:
                st.warning("⚠️ **Notice Regarding Cast & Crew:**")
                for w in res["warnings"]:
                    st.write(f"- {w}")
            else:
                st.success("✅ Director and cast members matched known historical profiles in the training dataset.")

        except Exception as e:
            st.error(f"Error computing prediction: {e}")

# -------------------------------------------------------------
# PAGE 2: DATASET EXPLORER
# -------------------------------------------------------------
elif page == "📊 Dataset Explorer":
    st.markdown('<p class="main-header">📊 Historical Dataset Explorer</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Filter, search, and visually analyze 7,919 verified historical Indian movies with ratings.</p>', unsafe_allow_html=True)

    # Interactive Filters
    st.sidebar.subheader("Dataset Filters")
    min_year, max_year = int(df["Year"].min()), int(df["Year"].max())
    year_range = st.sidebar.slider("Year Range", min_year, max_year, (1980, max_year))

    min_rate, max_rate = float(df["Rating"].min()), float(df["Rating"].max())
    rating_range = st.sidebar.slider("Rating Range", min_rate, max_rate, (min_rate, max_rate))

    selected_genre_filter = st.sidebar.selectbox("Filter by Genre", ["All"] + ALL_GENRES)

    filtered_df = df[
        (df["Year"] >= year_range[0]) &
        (df["Year"] <= year_range[1]) &
        (df["Rating"] >= rating_range[0]) &
        (df["Rating"] <= rating_range[1])
    ]

    if selected_genre_filter != "All":
        filtered_df = filtered_df[filtered_df["Genre"].str.contains(selected_genre_filter, case=False, na=False)]

    st.write(f"Displaying **{len(filtered_df):,}** matching movies out of {len(df):,} total.")

    # Data tabs
    tab1, tab2 = st.tabs(["Interactive Table", "Visual Distributions"])

    with tab1:
        st.dataframe(filtered_df, use_container_width=True, height=400)
        csv = filtered_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Download Filtered Data (CSV)",
            data=csv,
            file_name="filtered_movies.csv",
            mime="text/csv"
        )

    with tab2:
        c1, c2 = st.columns(2)
        with c1:
            fig_hist = px.histogram(
                filtered_df, x="Rating", nbins=30,
                title="Rating Distribution",
                color_discrete_sequence=["#3B82F6"]
            )
            st.plotly_chart(fig_hist, use_container_width=True)

        with c2:
            fig_scatter = px.scatter(
                filtered_df, x="Votes", y="Rating",
                log_x=True, hover_name="Name",
                title="Rating vs. User Votes (Log Scale)",
                color="Rating", color_continuous_scale="Viridis"
            )
            st.plotly_chart(fig_scatter, use_container_width=True)

# -------------------------------------------------------------
# PAGE 3: MODEL BENCHMARKS
# -------------------------------------------------------------
elif page == "📈 Model Benchmarks & Metrics":
    st.markdown('<p class="main-header">📈 Model Comparison & Evaluation</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Evaluation of regression techniques across 5-Fold Cross-Validation and held-out test data.</p>', unsafe_allow_html=True)

    if not metrics_df.empty:
        st.subheader("Model Leaderboard")
        st.dataframe(metrics_df.style.highlight_min(subset=["Test_MAE", "Test_RMSE"], color="#C6F6D5")
                                     .highlight_max(subset=["Test_R2"], color="#C6F6D5"),
                     use_container_width=True)

        col_b1, col_b2 = st.columns(2)
        with col_b1:
            fig_bar_mae = px.bar(
                metrics_df, x="Model", y="Test_MAE",
                title="Held-Out Test MAE (Lower is Better)",
                color="Test_MAE", color_continuous_scale="Teal"
            )
            st.plotly_chart(fig_bar_mae, use_container_width=True)

        with col_b2:
            fig_bar_r2 = px.bar(
                metrics_df, x="Model", y="Test_R2",
                title="Held-Out Test R² Variance Explained (Higher is Better)",
                color="Test_R2", color_continuous_scale="Purples"
            )
            st.plotly_chart(fig_bar_r2, use_container_width=True)

        csv_metrics = metrics_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Download Metrics Comparison Table (CSV)",
            data=csv_metrics,
            file_name="metrics_summary.csv",
            mime="text/csv"
        )
    else:
        st.warning("Metrics file not found. Please run training first.")

# -------------------------------------------------------------
# PAGE 4: INSIGHTS & FINDINGS
# -------------------------------------------------------------
elif page == "💡 Insights & Findings":
    st.markdown('<p class="main-header">💡 Factors That Influence Movie Ratings</p>', unsafe_allow_html=True)

    st.markdown("""
    ### Key Analytical Insights
    1. **Director and Lead Actor Reputation**:
       - The collaborative pairing of Director and Lead Actor (`Director_LeadActor_Avg_Rating`) is the single strongest factor associated with higher ratings, explaining over 20% of relative feature gain.
    2. **Engagement & Popularity Correlation**:
       - Higher vote volume (`Log_Votes`) shows a statistically positive correlation with higher ratings (\(r \approx 0.28\)). Acclaimed films attract wider user review participation.
    3. **Genre Association**:
       - Genres such as **Documentary** (mean: 7.02) and **Biography** (mean: 6.84) are associated with higher average ratings.
       - Commercial high-volume genres such as **Horror** (mean: 4.67) and **Action** (mean: 5.48) tend to receive lower average ratings.
    4. **Runtime & Era**:
       - Movies from older decades (pre-1970s) display higher average ratings (partly survivor bias of preserved classics).
       - Moderate to longer durations (125 - 150 minutes) are positively associated with critical acclaim compared to very short films.
    
    ### Limitations
    - **Unmeasured Quality Factors**: Script quality, cinematography, musical score, production budget, and marketing spend are not captured in the raw metadata.
    - **Survivor Bias**: Older low-rated movies are less likely to be cataloged with complete ratings on IMDb compared to contemporary releases.
    """)
