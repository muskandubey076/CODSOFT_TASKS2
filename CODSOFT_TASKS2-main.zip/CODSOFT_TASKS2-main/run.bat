@echo off
REM Run script for Movie Rating Prediction Project (Windows CMD/PowerShell)

IF "%1"=="" GOTO help
IF "%1"=="install" GOTO install
IF "%1"=="eda" GOTO eda
IF "%1"=="train" GOTO train
IF "%1"=="evaluate" GOTO evaluate
IF "%1"=="predict" GOTO predict
IF "%1"=="test" GOTO test
IF "%1"=="app" GOTO app
IF "%1"=="all" GOTO all
GOTO help

:install
echo [Step] Installing dependencies from requirements.txt...
pip install -r requirements.txt
GOTO end

:eda
echo [Step] Running Exploratory Data Analysis & Feature Plotting...
python -m src.eda
GOTO end

:train
echo [Step] Training Regression Models and Tuning Best Model...
python -m src.train
GOTO end

:evaluate
echo [Step] Evaluating Best Model and Generating Diagnostic Figures...
python -m src.evaluate
GOTO end

:predict
echo [Step] Running Prediction CLI Demonstration...
python -m src.predict --name "Dangal" --genre "Biography, Drama, Sport" --director "Nitesh Tiwari" --actor1 "Aamir Khan" --actor2 "Fatima Sana Shaikh" --actor3 "Sanya Malhotra" --year 2016 --duration 161 --votes 180000
GOTO end

:test
echo [Step] Running Pytest Suite...
pytest
GOTO end

:app
echo [Step] Launching Streamlit Interactive Web Application...
streamlit run app.py
GOTO end

:all
echo [Step] Executing Full End-to-End Pipeline...
call :eda
call :train
call :evaluate
call :test
call :predict
echo Pipeline execution complete!
GOTO end

:help
echo Movie Rating Prediction - CLI Commands:
echo   run.bat install   - Install required dependencies
echo   run.bat eda       - Run Exploratory Data Analysis
echo   run.bat train     - Train models and tune hyperparameters
echo   run.bat evaluate  - Generate diagnostic evaluation figures
echo   run.bat predict   - Run sample CLI prediction
echo   run.bat test      - Run automated pytest suite
echo   run.bat app       - Launch Streamlit interactive web dashboard
echo   run.bat all       - Run complete pipeline end-to-end
GOTO end

:end
