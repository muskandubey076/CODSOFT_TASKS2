"""
Exploratory Data Analysis script for Movie Rating Prediction.
Generates comprehensive visual figures saved to outputs/figures/ and
produces descriptive summaries.
"""

import logging
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

from src.config import FIGURES_DIR, LOG_FILE_PATH, LOGS_DIR
from src.data_loader import load_raw_data
from src.preprocess import clean_raw_data

FIGURES_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, mode="a", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("EDA")

# Set visualization aesthetic style
plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
plt.rcParams["font.sans-serif"] = "DejaVu Sans"
plt.rcParams["axes.edgecolor"] = "#cccccc"
plt.rcParams["axes.linewidth"] = 0.8


def run_eda():
    """Execute complete EDA pipeline and generate all required figures."""
    logger.info("Starting Exploratory Data Analysis...")

    # Load raw and clean
    raw_df = load_raw_data()
    clean_df, _ = clean_raw_data(raw_df)

    # 1. Missing Values Overview Chart (Raw Data)
    logger.info("Generating chart: 01_missing_values.png")
    fig, ax = plt.subplots(figsize=(10, 5))
    missing_pct = (raw_df.isnull().sum() / len(raw_df) * 100).sort_values(ascending=False)
    sns.barplot(x=missing_pct.values, y=missing_pct.index, palette="viridis", ax=ax, hue=missing_pct.index, legend=False)
    ax.set_title("Missing Values Percentage by Column (Raw Dataset)", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Percentage Missing (%)", fontsize=11)
    ax.set_ylabel("Column Name", fontsize=11)
    for i, v in enumerate(missing_pct.values):
        ax.text(v + 0.5, i, f"{v:.1f}%", va="center", fontsize=10, color="#333333")
    ax.set_xlim(0, max(missing_pct.values) + 10)
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "01_missing_values.png", dpi=300)
    plt.close(fig)

    # 2. Rating Distribution (Histogram + Box Plot)
    logger.info("Generating chart: 02_rating_distribution.png")
    fig, (ax_box, ax_hist) = plt.subplots(
        2, 1, figsize=(10, 7), sharex=True, gridspec_kw={"height_ratios": [0.25, 0.75]}
    )
    sns.boxplot(x=clean_df["Rating"], ax=ax_box, color="#4C72B0", fliersize=3)
    ax_box.set(xlabel="")
    ax_box.set_title("IMDb Movie Rating Distribution & Summary Boxplot", fontsize=14, fontweight="bold", pad=10)

    sns.histplot(clean_df["Rating"], kde=True, ax=ax_hist, color="#4C72B0", bins=30, edgecolor="white")
    mean_val = clean_df["Rating"].mean()
    median_val = clean_df["Rating"].median()
    ax_hist.axvline(mean_val, color="#C44E52", linestyle="--", linewidth=2, label=f"Mean: {mean_val:.2f}")
    ax_hist.axvline(median_val, color="#55A868", linestyle=":", linewidth=2, label=f"Median: {median_val:.2f}")
    ax_hist.set_xlabel("IMDb Rating (1 - 10)", fontsize=11)
    ax_hist.set_ylabel("Movie Count", fontsize=11)
    ax_hist.legend(loc="upper left", frameon=True)
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "02_rating_distribution.png", dpi=300)
    plt.close(fig)

    # 3. Average Rating by Genre
    logger.info("Generating chart: 03_rating_by_genre.png")
    genre_series = clean_df.set_index("Rating")["Genre"].dropna().str.split(", ").explode()
    genre_df = pd.DataFrame(genre_series).reset_index()
    genre_df = genre_df[genre_df["Genre"] != "Unknown"]
    genre_stats = genre_df.groupby("Genre")["Rating"].agg(["mean", "count"]).sort_values("mean", ascending=True)

    fig, ax = plt.subplots(figsize=(11, 7))
    colors = plt.cm.RdYlGn(np.linspace(0.2, 0.9, len(genre_stats)))
    bars = ax.barh(genre_stats.index, genre_stats["mean"], color=colors, edgecolor="none", height=0.7)
    ax.axvline(mean_val, color="black", linestyle="--", linewidth=1.5, label=f"Overall Avg ({mean_val:.2f})")
    ax.set_title("Average IMDb Rating by Genre (Sorted)", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Average Rating", fontsize=11)
    ax.set_xlim(3.0, 8.5)
    for bar, (_, row) in zip(bars, genre_stats.iterrows()):
        ax.text(
            bar.get_width() + 0.05,
            bar.get_y() + bar.get_height() / 2,
            f"{row['mean']:.2f} (n={int(row['count'])})",
            va="center",
            fontsize=9
        )
    ax.legend(loc="lower right")
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "03_rating_by_genre.png", dpi=300)
    plt.close(fig)

    # 4. Rating Trend Across Decades/Years
    logger.info("Generating chart: 04_rating_trend_year.png")
    year_stats = clean_df.groupby("Year")["Rating"].agg(["mean", "count", "std"]).reset_index()
    fig, ax1 = plt.subplots(figsize=(11, 5))
    ax2 = ax1.twinx()

    ax2.bar(year_stats["Year"], year_stats["count"], color="#cccccc", alpha=0.35, width=0.8, label="Movie Count")
    ax2.set_ylabel("Number of Movies", color="#888888", fontsize=11)
    ax2.grid(False)

    ax1.plot(year_stats["Year"], year_stats["mean"], color="#1f77b4", linewidth=2.5, marker="o", markersize=3, label="Avg Rating")
    ax1.fill_between(
        year_stats["Year"],
        year_stats["mean"] - 0.5 * year_stats["std"].fillna(0),
        year_stats["mean"] + 0.5 * year_stats["std"].fillna(0),
        color="#1f77b4",
        alpha=0.15
    )
    ax1.set_title("Historical IMDb Movie Rating Trend by Release Year (1917 - 2021)", fontsize=14, fontweight="bold", pad=12)
    ax1.set_xlabel("Release Year", fontsize=11)
    ax1.set_ylabel("Average Rating (1 - 10)", fontsize=11)
    ax1.set_ylim(3.5, 8.5)

    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc="upper right")
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "04_rating_trend_year.png", dpi=300)
    plt.close(fig)

    # 5. Top Directors by Average Rating (min 5 movies)
    logger.info("Generating chart: 05_top_directors.png")
    dir_stats = clean_df[clean_df["Director"] != "Unknown"].groupby("Director")["Rating"].agg(["mean", "count"])
    top_dirs = dir_stats[dir_stats["count"] >= 5].sort_values("mean", ascending=False).head(15)

    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x=top_dirs["mean"], y=top_dirs.index, palette="mako", ax=ax, hue=top_dirs.index, legend=False)
    ax.set_title("Top 15 Directors by Average Rating (Min. 5 Movies Directed)", fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Average Rating", fontsize=11)
    ax.set_xlim(5.0, 9.5)
    for i, (_, row) in enumerate(top_dirs.iterrows()):
        ax.text(row["mean"] + 0.05, i, f"{row['mean']:.2f} ({int(row['count'])} movies)", va="center", fontsize=9)
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "05_top_directors.png", dpi=300)
    plt.close(fig)

    # 6. Top Actors by Average Rating (min 5 movies)
    logger.info("Generating chart: 06_top_actors.png")
    actor_rows = []
    for _, row in clean_df.iterrows():
        for act in [row["Actor 1"], row["Actor 2"], row["Actor 3"]]:
            if act != "Unknown" and pd.notna(act):
                actor_rows.append({"Actor": act, "Rating": row["Rating"]})
    actor_df = pd.DataFrame(actor_rows)
    act_stats = actor_df.groupby("Actor")["Rating"].agg(["mean", "count"])
    top_acts = act_stats[act_stats["count"] >= 8].sort_values("mean", ascending=False).head(15)

    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x=top_acts["mean"], y=top_acts.index, palette="rocket", ax=ax, hue=top_acts.index, legend=False)
    ax.set_title("Top 15 Actors by Average Rating (Min. 8 Movies)", fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Average Rating", fontsize=11)
    ax.set_xlim(5.0, 9.5)
    for i, (_, row) in enumerate(top_acts.iterrows()):
        ax.text(row["mean"] + 0.05, i, f"{row['mean']:.2f} ({int(row['count'])} films)", va="center", fontsize=9)
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "06_top_actors.png", dpi=300)
    plt.close(fig)

    # 7. Scatter Plots: Rating vs Numeric Features
    logger.info("Generating chart: 07_numeric_relationships.png")
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))

    # Votes vs Rating (log scale)
    sns.scatterplot(data=clean_df, x="Votes", y="Rating", alpha=0.3, color="#2b5c8f", ax=axes[0])
    axes[0].set_xscale("log")
    axes[0].set_title("IMDb Rating vs. Votes (Log Scale)", fontsize=12, fontweight="bold")
    axes[0].set_xlabel("Votes (Logarithmic)", fontsize=10)
    axes[0].set_ylabel("Rating", fontsize=10)

    # Duration vs Rating
    dur_data = clean_df.dropna(subset=["Duration"])
    sns.scatterplot(data=dur_data, x="Duration", y="Rating", alpha=0.3, color="#2b8f5c", ax=axes[1])
    axes[1].set_title("IMDb Rating vs. Duration (Minutes)", fontsize=12, fontweight="bold")
    axes[1].set_xlabel("Runtime (Minutes)", fontsize=10)
    axes[1].set_ylabel("Rating", fontsize=10)

    # Year vs Rating
    sns.scatterplot(data=clean_df, x="Year", y="Rating", alpha=0.3, color="#8f2b5c", ax=axes[2])
    axes[2].set_title("IMDb Rating vs. Release Year", fontsize=12, fontweight="bold")
    axes[2].set_xlabel("Release Year", fontsize=10)
    axes[2].set_ylabel("Rating", fontsize=10)

    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "07_numeric_relationships.png", dpi=300)
    plt.close(fig)

    # 8. Correlation Heatmap
    logger.info("Generating chart: 08_correlation_heatmap.png")
    corr_df = clean_df[["Rating", "Year", "Duration", "Votes"]].copy()
    corr_df["Log_Votes"] = np.log1p(corr_df["Votes"])
    corr_matrix = corr_df.corr()

    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(
        corr_matrix,
        annot=True,
        cmap="coolwarm",
        vmin=-0.4,
        vmax=0.4,
        fmt=".3f",
        linewidths=0.5,
        cbar_kws={"shrink": 0.8},
        ax=ax
    )
    ax.set_title("Pearson Correlation Heatmap (Numeric Features)", fontsize=13, fontweight="bold", pad=12)
    plt.tight_layout()
    fig.savefig(FIGURES_DIR / "08_correlation_heatmap.png", dpi=300)
    plt.close(fig)

    # 9. Save Cleaned Processed Data
    from src.config import CLEANED_DATA_PATH, PROCESSED_DATA_DIR
    PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
    clean_df.to_csv(CLEANED_DATA_PATH, index=False)
    logger.info(f"Cleaned dataset saved to {CLEANED_DATA_PATH} with {len(clean_df)} rows.")

    logger.info("All EDA charts generated successfully.")


if __name__ == "__main__":
    run_eda()
