"""
Data loader module for Movie Rating Prediction.
Handles loading raw data, initial audit checks, and basic validations.
"""

import logging
from pathlib import Path
from typing import Optional, Tuple
import pandas as pd
from src.config import RAW_DATA_PATH, LOG_FILE_PATH, LOGS_DIR

LOGS_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, mode="a", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("DataLoader")


def load_raw_data(filepath: Optional[Path] = None) -> pd.DataFrame:
    """
    Load raw IMDb movie data with proper encoding.

    Args:
        filepath: Optional path to raw dataset. Defaults to config RAW_DATA_PATH.

    Returns:
        pd.DataFrame containing raw data.
    """
    path = filepath or RAW_DATA_PATH
    if not path.exists():
        logger.error(f"Raw data file not found at {path}")
        raise FileNotFoundError(f"Raw data file not found at {path}")

    # IMDb Movies India uses latin1 encoding due to accented characters in names
    encodings = ["utf-8", "latin1", "cp1252", "iso-8859-1"]
    for enc in encodings:
        try:
            df = pd.read_csv(path, encoding=enc)
            logger.info(f"Loaded raw data successfully using {enc} encoding. Shape: {df.shape}")
            return df
        except UnicodeDecodeError:
            continue

    raise ValueError(f"Could not decode {path} with standard encodings: {encodings}")


def get_dataset_summary(df: pd.DataFrame) -> dict:
    """
    Return dictionary summary of dataset for logging and auditing.
    """
    return {
        "num_rows": len(df),
        "num_cols": len(df.columns),
        "columns": list(df.columns),
        "missing_counts": df.isnull().sum().to_dict(),
        "duplicates": int(df.duplicated().sum())
    }
