"""
Feature Engineering module for Movie Rating Prediction.
Implements leak-free target encoding, genre multi-label one-hot encoding,
and derived feature extraction wrapped in custom scikit-learn transformers.
"""

import logging
from typing import List, Dict, Optional
import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.model_selection import KFold

from src.config import (
    ALL_GENRES,
    PERSON_COLS,
    TARGET_ENCODING_SMOOTHING,
    RANDOM_STATE,
    LOG_FILE_PATH,
    LOGS_DIR
)

LOGS_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, mode="a", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Features")


class MovieFeatureEngineer(BaseEstimator, TransformerMixin):
    """
    Scikit-learn compatible transformer for engineering movie features:
    1. Multi-label binary indicators for genres.
    2. Genre count and cast count features.
    3. Derived movie age and decade.
    4. Log-transformed votes and duration features.
    5. Smoothed, leak-free target encodings for Director and Actors with frequency counts.
       (Uses out-of-fold computation during fit_transform on training data to prevent leakage).
    """

    def __init__(
        self,
        smoothing: float = TARGET_ENCODING_SMOOTHING,
        genres: Optional[List[str]] = None,
        person_cols: Optional[List[str]] = None,
        cv_folds: int = 5
    ):
        self.smoothing = smoothing
        self.genres = genres or ALL_GENRES
        self.person_cols = person_cols or PERSON_COLS
        self.cv_folds = cv_folds

        # Fitted statistics
        self.global_target_mean_: float = 5.84
        self.person_stats_: Dict[str, Dict[str, Dict[str, float]]] = {}
        self.feature_names_: List[str] = []
        self.impute_values_: Dict[str, float] = {}

    def fit(self, X: pd.DataFrame, y: pd.Series):
        """
        Fit feature encoder on training set only (strictly leak-free).
        """
        X_df = X.copy()
        y_ser = pd.Series(y).reset_index(drop=True)
        X_df = X_df.reset_index(drop=True)

        self.global_target_mean_ = float(y_ser.mean())

        # Impute medians for numeric columns from training data only
        # Year
        year_median = X_df["Year"].dropna().median() if "Year" in X_df else 2000.0
        self.impute_values_["Year"] = float(year_median if not np.isnan(year_median) else 2000.0)

        # Duration
        dur_median = X_df["Duration"].dropna().median() if "Duration" in X_df else 130.0
        self.impute_values_["Duration"] = float(dur_median if not np.isnan(dur_median) else 130.0)

        # Votes
        votes_median = X_df["Votes"].dropna().median() if "Votes" in X_df else 50.0
        self.impute_values_["Votes"] = float(votes_median if not np.isnan(votes_median) else 50.0)

        # Compute smoothed target encoding statistics for each person column on training set
        # Smoothed Mean = (count * mean + smoothing * global_mean) / (count + smoothing)
        self.person_stats_ = {}
        for col in self.person_cols:
            if col in X_df.columns:
                stats = {}
                grouped = y_ser.groupby(X_df[col].fillna("Unknown"))
                counts = grouped.count()
                means = grouped.mean()

                for name, count in counts.items():
                    raw_mean = means[name]
                    smoothed_val = (count * raw_mean + self.smoothing * self.global_target_mean_) / (count + self.smoothing)
                    stats[name] = {
                        "smoothed_rating": float(smoothed_val),
                        "movie_count": int(count)
                    }
                self.person_stats_[col] = stats

        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Transform test or new prediction samples using fitted training statistics.
        """
        X_df = X.copy().reset_index(drop=True)
        transformed = pd.DataFrame(index=X_df.index)

        # 1. Impute and create numeric features
        year_val = X_df["Year"].fillna(self.impute_values_["Year"]).astype(float)
        dur_val = X_df["Duration"].fillna(self.impute_values_["Duration"]).astype(float)
        votes_val = X_df["Votes"].fillna(self.impute_values_["Votes"]).astype(float).clip(lower=0)

        transformed["Year"] = year_val
        transformed["Duration"] = dur_val
        transformed["Votes"] = votes_val
        transformed["Log_Votes"] = np.log1p(votes_val)

        # 2. Derived features
        transformed["Movie_Age"] = (2024.0 - year_val).clip(lower=0)
        transformed["Decade"] = (year_val // 10) * 10

        # 3. Genre features (multi-label one-hot encoding)
        genre_col = X_df["Genre"].fillna("").astype(str)
        transformed["Genre_Count"] = genre_col.apply(
            lambda g: 0 if g in ["", "nan", "Unknown"] else len([x for x in g.split(",") if x.strip()])
        )

        for genre in self.genres:
            transformed[f"Genre_{genre}"] = genre_col.apply(
                lambda g: 1 if genre.lower() in [x.strip().lower() for x in g.split(",")] else 0
            )

        # 4. Cast count (number of known actors listed)
        def count_known_actors(row):
            cnt = 0
            for a in ["Actor 1", "Actor 2", "Actor 3"]:
                if a in row and pd.notna(row[a]) and str(row[a]).strip() not in ["", "nan", "Unknown"]:
                    cnt += 1
            return cnt

        transformed["Cast_Size"] = X_df.apply(count_known_actors, axis=1)

        # 5. Apply fitted smoothed target encoding and counts for person columns
        for col in self.person_cols:
            stat_map = self.person_stats_.get(col, {})
            smoothed_vals = []
            count_vals = []
            col_series = X_df[col].fillna("Unknown").astype(str) if col in X_df else pd.Series(["Unknown"] * len(X_df))

            for name in col_series:
                if name in stat_map:
                    smoothed_vals.append(stat_map[name]["smoothed_rating"])
                    count_vals.append(stat_map[name]["movie_count"])
                else:
                    # Unseen category fallback
                    smoothed_vals.append(self.global_target_mean_)
                    count_vals.append(0)

            col_slug = col.replace(" ", "_")
            transformed[f"{col_slug}_Rating_Enc"] = smoothed_vals
            transformed[f"{col_slug}_Movie_Count"] = count_vals

        # Aggregate team score: combination of Director and Lead Actor
        transformed["Director_LeadActor_Avg_Rating"] = (
            transformed["Director_Rating_Enc"] + transformed["Actor_1_Rating_Enc"]
        ) / 2.0

        self.feature_names_ = list(transformed.columns)
        return transformed

    def fit_transform(self, X: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
        """
        Fit to training data and compute OUT-OF-FOLD (OOF) target encodings for the training set.
        This completely eliminates target leakage on the training set while preserving true shrinkage.
        """
        self.fit(X, y)
        X_df = X.copy().reset_index(drop=True)
        y_ser = pd.Series(y).reset_index(drop=True)

        # First transform without person columns to get all base & genre features
        base_df = self.transform(X_df)

        # Overwrite person rating encodings using 5-fold cross-validation out-of-fold to prevent leakage
        kf = KFold(n_splits=self.cv_folds, shuffle=True, random_state=RANDOM_STATE)

        for col in self.person_cols:
            col_slug = col.replace(" ", "_")
            oof_encoded = np.full(len(X_df), self.global_target_mean_, dtype=float)

            for train_idx, val_idx in kf.split(X_df, y_ser):
                X_tr_col = X_df[col].iloc[train_idx].fillna("Unknown")
                y_tr = y_ser.iloc[train_idx]
                fold_global_mean = float(y_tr.mean())

                grouped = y_tr.groupby(X_tr_col)
                counts = grouped.count()
                means = grouped.mean()

                val_col = X_df[col].iloc[val_idx].fillna("Unknown")
                val_encoded = []
                for name in val_col:
                    if name in counts:
                        cnt = counts[name]
                        raw_mean = means[name]
                        val = (cnt * raw_mean + self.smoothing * fold_global_mean) / (cnt + self.smoothing)
                    else:
                        val = fold_global_mean
                    val_encoded.append(val)
                oof_encoded[val_idx] = val_encoded

            base_df[f"{col_slug}_Rating_Enc"] = oof_encoded

        base_df["Director_LeadActor_Avg_Rating"] = (
            base_df["Director_Rating_Enc"] + base_df["Actor_1_Rating_Enc"]
        ) / 2.0

        self.feature_names_ = list(base_df.columns)
        return base_df

    def get_feature_names_out(self, input_features=None):
        return np.array(self.feature_names_)
