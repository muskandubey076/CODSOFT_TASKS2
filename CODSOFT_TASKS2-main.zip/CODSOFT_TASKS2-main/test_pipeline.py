"""
Unit and Integration Test Suite for Movie Rating Prediction.
Verifies:
1. Full end-to-end pipeline execution on real data.
2. Data leakage test: ensures no validation/test ratings were used to compute training target encodings.
3. Input validation: predict.py rejects empty, wrong-type, and out-of-range inputs with clear exceptions.
4. Model artifacts: saved pipeline loads properly and predicts within [1.0, 10.0].
5. Reproducibility test: identical predictions with the same random_state.
"""

import pytest
import numpy as np
import pandas as pd
import joblib

from src.config import BEST_MODEL_PATH, CLEANED_DATA_PATH, RANDOM_STATE
from src.features import MovieFeatureEngineer
from src.predict import predict_rating, validate_movie_input, get_pipeline


def test_saved_model_loads_and_predicts_in_valid_range():
    """Ensure saved model exists, loads cleanly, and outputs ratings between 1.0 and 10.0."""
    pipeline = get_pipeline()
    assert pipeline is not None, "Pipeline failed to load."

    sample = {
        "Name": "Sample Test Movie",
        "Genre": "Action, Crime",
        "Director": "Anurag Kashyap",
        "Actor 1": "Nawazuddin Siddiqui",
        "Actor 2": "Manoj Bajpayee",
        "Actor 3": "Richa Chadha",
        "Year": 2012,
        "Duration": 160,
        "Votes": 50000
    }
    result = predict_rating(sample)
    pred_rating = result["predicted_rating"]

    assert isinstance(pred_rating, float)
    assert 1.0 <= pred_rating <= 10.0, f"Predicted rating {pred_rating} out of valid bounds [1.0, 10.0]"


def test_input_validation_and_error_handling():
    """Verify that empty, wrong-type, and impossible values raise informative ValueErrors."""
    # Empty dictionary
    with pytest.raises(ValueError, match="cannot be empty"):
        validate_movie_input({})

    # Wrong data type for dictionary
    with pytest.raises(ValueError, match="must be a dictionary"):
        validate_movie_input("not a dict")

    # Impossible Year
    with pytest.raises(ValueError, match="Year must be between"):
        validate_movie_input({"Year": 1850})

    # Impossible Duration
    with pytest.raises(ValueError, match="Duration must be between"):
        validate_movie_input({"Duration": 5})

    # Negative Votes
    with pytest.raises(ValueError, match="Votes count cannot be negative"):
        validate_movie_input({"Votes": -50})


def test_unknown_person_fallback_mechanism():
    """Check that unknown director and actors trigger warnings and fallback to global mean."""
    sample = {
        "Name": "Unknown Team Film",
        "Genre": "Drama",
        "Director": "Nonexistent Director 9999",
        "Actor 1": "Nonexistent Actor 9999",
        "Year": 2022,
        "Duration": 120,
        "Votes": 100
    }
    result = predict_rating(sample)
    assert len(result["warnings"]) >= 2
    assert "unseen or unknown" in result["warnings"][0]
    assert 1.0 <= result["predicted_rating"] <= 10.0


def test_no_data_leakage_in_feature_engineering():
    """
    Verify that out-of-fold target encoding does not leak the test set target values.
    Specifically, training statistics must not be influenced by test target values.
    """
    df = pd.read_csv(CLEANED_DATA_PATH).head(200)
    X = df.drop(columns=["Rating"])
    y = df["Rating"]

    # Split into train (first 150) and test (last 50)
    X_train, y_train = X.iloc[:150], y.iloc[:150]
    X_test, y_test = X.iloc[150:], y.iloc[150:]

    fe = MovieFeatureEngineer(smoothing=10.0)
    fe.fit(X_train, y_train)

    # Change test target to extreme value (1000.0) - should NOT affect transformer fitted attributes
    y_test_fake = y_test.copy() + 1000.0

    # Ensure fitted stats are purely from X_train and y_train
    assert np.isclose(fe.global_target_mean_, y_train.mean())
    assert fe.global_target_mean_ != y_test_fake.mean()

    # Transformed test output should depend ONLY on trained stats
    trans_test = fe.transform(X_test)
    assert not trans_test.isnull().any().any(), "Transformed features contain unexpected NaNs."


def test_reproducibility():
    """Verify that predictions on identical inputs yield reproducible, deterministic scores."""
    sample = {
        "Name": "Reproducibility Check",
        "Genre": "Comedy",
        "Director": "Rajkumar Hirani",
        "Actor 1": "Aamir Khan",
        "Year": 2014,
        "Duration": 153,
        "Votes": 200000
    }
    res1 = predict_rating(sample)["predicted_rating"]
    res2 = predict_rating(sample)["predicted_rating"]
    assert res1 == res2, f"Predictions are non-deterministic: {res1} vs {res2}"
