"""
Prediction Interface Module for Movie Rating Prediction.
Provides a clean Python API function and a command-line interface (CLI)
that accepts movie details (genre, director, actors, year, duration, votes)
and returns a predicted rating.
Includes comprehensive input validation, unknown category handling, and friendly error messages.
"""

import sys
import argparse
import logging
from pathlib import Path
from typing import Dict, Any, Union, Optional
import joblib
import pandas as pd
import numpy as np

from src.config import BEST_MODEL_PATH, LOG_FILE_PATH, LOGS_DIR

LOGS_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, mode="a", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Predict")

# Global pipeline cache
_PIPELINE = None


def get_pipeline():
    """Load and cache the trained model pipeline."""
    global _PIPELINE
    if _PIPELINE is None:
        if not BEST_MODEL_PATH.exists():
            raise FileNotFoundError(
                f"Trained model not found at '{BEST_MODEL_PATH}'. "
                "Please run 'python -m src.train' first."
            )
        _PIPELINE = joblib.load(BEST_MODEL_PATH)
    return _PIPELINE


def validate_movie_input(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate input movie fields:
    - Checks required keys and non-empty values.
    - Validates data types for Year, Duration, Votes.
    - Returns standardized dictionary or raises ValueError with user-friendly guidance.
    """
    if not isinstance(data, dict):
        raise ValueError("Input data must be a dictionary containing movie details.")

    if not data:
        raise ValueError("Input movie details dictionary cannot be empty.")

    validated = {}

    # Name
    name = str(data.get("Name", "Untitled Movie")).strip()
    validated["Name"] = name if name else "Untitled Movie"

    # Year validation
    year_raw = data.get("Year", 2020)
    try:
        year_val = float(year_raw)
        if not (1900 <= year_val <= 2030):
            raise ValueError(f"Year must be between 1900 and 2030. Received: {year_raw}")
        validated["Year"] = year_val
    except (ValueError, TypeError) as e:
        if "Year must be between" in str(e):
            raise
        raise ValueError(f"Invalid Year '{year_raw}'. Year must be a valid numeric year (e.g., 2021).")

    # Duration validation
    dur_raw = data.get("Duration", 120)
    try:
        dur_val = float(dur_raw)
        if not (10 <= dur_val <= 600):
            raise ValueError(f"Duration must be between 10 and 600 minutes. Received: {dur_raw}")
        validated["Duration"] = dur_val
    except (ValueError, TypeError) as e:
        if "Duration must be between" in str(e):
            raise
        raise ValueError(f"Invalid Duration '{dur_raw}'. Must be a positive number in minutes (e.g., 130).")

    # Votes validation
    votes_raw = data.get("Votes", 100)
    try:
        votes_val = float(str(votes_raw).replace(",", "").strip())
        if votes_val < 0:
            raise ValueError("Votes count cannot be negative.")
        validated["Votes"] = votes_val
    except (ValueError, TypeError) as e:
        if "Votes count cannot be negative" in str(e):
            raise
        raise ValueError(f"Invalid Votes count '{votes_raw}'. Votes must be a non-negative number.")

    # Genre
    genre_raw = str(data.get("Genre", "Drama")).strip()
    if not genre_raw:
        genre_raw = "Drama"
    validated["Genre"] = genre_raw

    # Director and Cast
    for col in ["Director", "Actor 1", "Actor 2", "Actor 3"]:
        val = str(data.get(col, "Unknown")).strip()
        validated[col] = val if val else "Unknown"

    return validated


def predict_rating(movie_details: Dict[str, Any]) -> Dict[str, Any]:
    """
    Predict movie rating from a dictionary of movie attributes.

    Args:
        movie_details: Dictionary containing:
            - 'Name' (str, optional)
            - 'Genre' (str, e.g., 'Action, Crime')
            - 'Director' (str)
            - 'Actor 1' (str)
            - 'Actor 2' (str, optional)
            - 'Actor 3' (str, optional)
            - 'Year' (int/float, optional, default 2020)
            - 'Duration' (int/float, optional, default 125)
            - 'Votes' (int/float, optional, default 100)

    Returns:
        Dictionary with:
            - 'predicted_rating': float rounded to 2 decimal places (clamped between 1.0 and 10.0)
            - 'warnings': list of helpful notices (e.g., unseen director/actor fallbacks)
            - 'input_summary': validated input dictionary
    """
    validated = validate_movie_input(movie_details)
    pipeline = get_pipeline()
    fe = pipeline.named_steps["feature_engineer"]

    warnings = []
    # Check for unseen director or actors
    for person_col in ["Director", "Actor 1", "Actor 2", "Actor 3"]:
        person_name = validated.get(person_col, "Unknown")
        known_stats = fe.person_stats_.get(person_col, {})
        if person_name not in known_stats or person_name == "Unknown":
            warnings.append(
                f"{person_col} '{person_name}' is unseen or unknown in the training dataset. "
                f"Using smoothed global fallback score ({fe.global_target_mean_:.2f})."
            )

    # Convert to single-row DataFrame
    input_df = pd.DataFrame([validated])
    raw_pred = pipeline.predict(input_df)[0]
    # Bound rating to official 1.0 to 10.0 range
    bounded_pred = float(np.clip(raw_pred, 1.0, 10.0))

    return {
        "predicted_rating": round(bounded_pred, 2),
        "warnings": warnings,
        "input_summary": validated
    }


def parse_args():
    parser = argparse.ArgumentParser(
        description="Predict Movie Rating using trained Machine Learning model."
    )
    parser.add_argument("--name", type=str, default="Untitled Film", help="Movie Title")
    parser.add_argument("--genre", type=str, required=True, help="Movie Genre(s), e.g. 'Action, Crime, Drama'")
    parser.add_argument("--director", type=str, required=True, help="Director Name")
    parser.add_argument("--actor1", type=str, required=True, help="Lead Actor Name")
    parser.add_argument("--actor2", type=str, default="Unknown", help="Supporting Actor 2")
    parser.add_argument("--actor3", type=str, default="Unknown", help="Supporting Actor 3")
    parser.add_argument("--year", type=float, default=2021.0, help="Release Year (e.g. 2021)")
    parser.add_argument("--duration", type=float, default=130.0, help="Duration in minutes (e.g. 135)")
    parser.add_argument("--votes", type=float, default=500.0, help="Estimated / Actual user votes")
    return parser.parse_args()


def main():
    args = parse_args()
    data = {
        "Name": args.name,
        "Genre": args.genre,
        "Director": args.director,
        "Actor 1": args.actor1,
        "Actor 2": args.actor2,
        "Actor 3": args.actor3,
        "Year": args.year,
        "Duration": args.duration,
        "Votes": args.votes
    }

    try:
        result = predict_rating(data)
        print("\n" + "=" * 60)
        print("[MOVIE RATING PREDICTION RESULT]")
        print("=" * 60)
        print(f"Movie Title:       {result['input_summary']['Name']}")
        print(f"Director:          {result['input_summary']['Director']}")
        print(f"Lead Cast:         {result['input_summary']['Actor 1']}, {result['input_summary']['Actor 2']}, {result['input_summary']['Actor 3']}")
        print(f"Genre:             {result['input_summary']['Genre']}")
        print(f"Year / Duration:   {int(result['input_summary']['Year'])} | {int(result['input_summary']['Duration'])} min")
        print(f"Estimated Votes:   {int(result['input_summary']['Votes']):,}")
        print("-" * 60)
        print(f">> PREDICTED RATING: {result['predicted_rating']} / 10.0")
        print("-" * 60)
        if result["warnings"]:
            print("[Notices & Fallbacks]")
            for w in result["warnings"]:
                print(f"  - {w}")
        print("=" * 60 + "\n")
    except Exception as e:
        print(f"\n[Error during prediction]: {e}\n", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
