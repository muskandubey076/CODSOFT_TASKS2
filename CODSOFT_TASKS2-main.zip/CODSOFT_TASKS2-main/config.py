"""
Central Configuration module for Movie Rating Prediction.
Defines directory paths, model hyperparameters, random seeds, and feature lists.
"""

from pathlib import Path

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_PATH = DATA_DIR / "IMDb Movies India.csv"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
CLEANED_DATA_PATH = PROCESSED_DATA_DIR / "cleaned_movies.csv"

MODELS_DIR = BASE_DIR / "models"
BEST_MODEL_PATH = MODELS_DIR / "best_movie_rating_model.joblib"

OUTPUTS_DIR = BASE_DIR / "outputs"
FIGURES_DIR = OUTPUTS_DIR / "figures"
METRICS_CSV_PATH = OUTPUTS_DIR / "metrics.csv"
METRICS_MD_PATH = OUTPUTS_DIR / "metrics.md"
DATA_AUDIT_PATH = OUTPUTS_DIR / "data_audit.md"
LOGS_DIR = BASE_DIR / "logs"
LOG_FILE_PATH = LOGS_DIR / "project.log"

# Random state for total reproducibility
RANDOM_STATE = 42

# Train / Test split ratio
TEST_SIZE = 0.20

# Cross validation folds
CV_FOLDS = 5

# Smoothing factor (m-estimate weight) for target encoding
TARGET_ENCODING_SMOOTHING = 10.0

# Target column name
TARGET_COL = "Rating"

# Known genres list across historical IMDb India data
ALL_GENRES = [
    "Action", "Adventure", "Animation", "Biography", "Comedy", "Crime",
    "Documentary", "Drama", "Family", "Fantasy", "History", "Horror",
    "Music", "Musical", "Mystery", "News", "Romance", "Sci-Fi",
    "Sport", "Thriller", "War", "Western"
]

# High cardinality categorical columns
PERSON_COLS = ["Director", "Actor 1", "Actor 2", "Actor 3"]
