# Data Audit Report: IMDb Movies India Dataset

## 1. Overview & File Roles
- **File Name:** `IMDb Movies India.csv`
- **Assigned Role:** Primary historical dataset. Only one dataset file exists.
- **Data Scenario:** **Case C** (Single file with rating column). A train/test split (80% train, 20% test, `random_state=42`) is applied for model training, tuning, and unbiased final evaluation.
- **Target Column:** `Rating`
  - **Reason for selection:** `Rating` represents the user/critic evaluation score given to each movie on IMDb (continuous float ranging from 1.0 to 10.0), matching the objective to predict movie ratings.
- **Dataset Dimensions:** 15,509 rows and 10 columns.
- **Duplicate Rows:** 6 exact duplicate rows identified in the raw file.

## 2. Column Summary & Data Types

| Column Name | Raw Data Type | Missing Count | Missing % | Description |
| :--- | :--- | :--- | :--- | :--- |
| `Name` | `object` (string) | 0 | 0.00% | Name/title of the movie |
| `Year` | `object` (string) | 528 | 3.40% | Release year formatted as `(YYYY)` |
| `Duration` | `object` (string) | 8269 | 53.32% | Runtime formatted as `X min` |
| `Genre` | `object` (string) | 1877 | 12.10% | Comma-separated list of movie genres |
| `Rating` | `float64` (numeric) | 7590 | 48.94% | **Target**: Movie rating score (1.0 to 10.0) |
| `Votes` | `object` (string) | 7589 | 48.93% | Number of user votes, formatted with commas |
| `Director` | `object` (string) | 525 | 3.39% | Primary director name |
| `Actor 1` | `object` (string) | 1617 | 10.43% | Lead actor / primary cast |
| `Actor 2` | `object` (string) | 2384 | 15.37% | Supporting actor / second lead |
| `Actor 3` | `object` (string) | 3144 | 20.27% | Supporting actor / third lead |

## 3. First 5 Rows (Raw)

|    | Name                               | Year   | Duration   | Genre           |   Rating |   Votes | Director           | Actor 1      | Actor 2            | Actor 3         |
|---:|:-----------------------------------|:-------|:-----------|:----------------|---------:|--------:|:-------------------|:-------------|:-------------------|:----------------|
|  0 |                                    | nan    | nan        | Drama           |    nan   |     nan | J.S. Randhawa      | Manmauji     | Birbal             | Rajendra Bhatia |
|  1 | #Gadhvi (He thought he was Gandhi) | (2019) | 109 min    | Drama           |      7   |       8 | Gaurav Bakshi      | Rasika Dugal | Vivek Ghamande     | Arvind Jangid   |
|  2 | #Homecoming                        | (2021) | 90 min     | Drama, Musical  |    nan   |     nan | Soumyajit Majumdar | Sayani Gupta | Plabita Borthakur  | Roy Angana      |
|  3 | #Yaaram                            | (2019) | 110 min    | Comedy, Romance |      4.4 |      35 | Ovais Khan         | Prateik      | Ishita Raj         | Siddhant Kapoor |
|  4 | ...And Once Again                  | (2010) | 105 min    | Drama           |    nan   |     nan | Amol Palekar       | Rajat Kapoor | Rituparna Sengupta | Antara Mali     |

## 4. Observations & Preprocessing Strategy
1. **Target Filtering:** 7,590 rows have missing ratings. Per mandatory data rules, rows without a target rating will be dropped (never imputed).
2. **Text Cleaning & Type Conversions:**
   - `Year`: Strip parentheses `(2019)` -> integer `2019`.
   - `Duration`: Extract digits `109 min` -> float/int `109` (minutes).
   - `Votes`: Remove commas `1,086` -> integer `1086`.
   - `Genre`: Multi-label strings split and one-hot encoded into individual binary flags.
   - Categorical fields (`Director`, `Actor 1`, `Actor 2`, `Actor 3`): High-cardinality categorical variables encoded via leak-free out-of-fold smoothed target encoding and frequency counts.
3. **Invalid & Outlier Checks:**
   - Ratings confirmed between 1.0 and 10.0.
   - Year range confirmed realistic for cinema history (1913 - 2022).
   - Duration values confirmed positive and realistic.
