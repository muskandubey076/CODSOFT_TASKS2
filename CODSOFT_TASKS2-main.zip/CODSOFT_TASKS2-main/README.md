# CODSOFT_TASKS2
Developed a machine learning model to predict movie ratings using data preprocessing, feature analysis, and predictive modeling.
