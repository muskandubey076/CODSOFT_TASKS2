"""
Preprocessing module for Movie Rating Prediction.
Handles data cleaning, numeric string conversion, missing target removal,
and feature imputation adhering to leak-free and non-fabricating rules.
"""

import logging
import re
from typing import Tuple
import pandas as pd
import numpy as np

from src.config import TARGET_COL, LOG_FILE_PATH, LOGS_DIR

LOGS_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, mode="a", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Preprocess")


def clean_raw_data(df: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    """
    Cleans raw IMDb dataset:
    - Removes exact duplicate rows.
    - Drops rows where target (Rating) is missing (never imputed).
    - Converts Year '(YYYY)' into integer.
    - Converts Duration 'XXX min' into integer minutes.
    - Converts Votes 'X,XXX' into numeric integer.
    - Standardizes text columns (strips whitespace, sets 'Unknown' for missing names/cast).
    - Checks impossible/extreme values (ratings outside [1.0, 10.0], negative durations).

    Args:
        df: Raw DataFrame.

    Returns:
        Tuple of (Cleaned DataFrame, Audit metrics dictionary).
    """
    audit = {}
    init_rows = len(df)
    audit["initial_rows"] = init_rows

    # 1. Drop duplicates
    df = df.copy()
    duplicates_count = int(df.duplicated().sum())
    df = df.drop_duplicates()
    audit["duplicates_removed"] = duplicates_count
    logger.info(f"Removed {duplicates_count} duplicate rows.")

    # 2. Drop rows where target is missing
    missing_target_count = int(df[TARGET_COL].isnull().sum())
    df = df.dropna(subset=[TARGET_COL]).copy()
    audit["missing_target_dropped"] = missing_target_count
    logger.info(f"Dropped {missing_target_count} rows with missing rating target.")

    # 3. Clean Year: strip non-digits, extract 4-digit year
    def parse_year(val):
        if pd.isna(val):
            return np.nan
        match = re.search(r"(\d{4})", str(val))
        return int(match.group(1)) if match else np.nan

    df["Year"] = df["Year"].apply(parse_year)

    # 4. Clean Duration: extract numeric minutes
    def parse_duration(val):
        if pd.isna(val):
            return np.nan
        match = re.search(r"(\d+)", str(val))
        return float(match.group(1)) if match else np.nan

    df["Duration"] = df["Duration"].apply(parse_duration)

    # 5. Clean Votes: strip commas and parse as float/int
    def parse_votes(val):
        if pd.isna(val):
            return np.nan
        val_str = str(val).replace(",", "").strip()
        try:
            return float(val_str)
        except ValueError:
            return np.nan

    df["Votes"] = df["Votes"].apply(parse_votes)

    # 6. Verify and filter invalid/impossible values
    valid_mask = (df[TARGET_COL] >= 1.0) & (df[TARGET_COL] <= 10.0)
    invalid_ratings = int((~valid_mask).sum())
    if invalid_ratings > 0:
        logger.warning(f"Found {invalid_ratings} impossible ratings outside [1.0, 10.0]. Filtering.")
        df = df[valid_mask]
    audit["invalid_ratings_dropped"] = invalid_ratings

    # Impossible duration or year check
    if df["Duration"].notnull().any():
        neg_dur = (df["Duration"] <= 0).sum()
        if neg_dur > 0:
            df.loc[df["Duration"] <= 0, "Duration"] = np.nan

    # Standardize string fields
    str_cols = ["Name", "Genre", "Director", "Actor 1", "Actor 2", "Actor 3"]
    for col in str_cols:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()
            df.loc[df[col].isin(["nan", "None", ""]), col] = "Unknown"

    audit["cleaned_rows"] = len(df)
    logger.info(f"Cleaning complete. Remaining clean rows: {len(df)}")
    return df, audit
